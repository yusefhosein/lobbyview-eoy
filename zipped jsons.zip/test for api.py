import os
import google.generativeai as genai
import fitz  # PyMuPDF
import base64
from PIL import Image
import io
import json
import time # For adding a small delay between API calls
import datetime # For timestamping log entries

# --- Configuration ---
# Ensure your GOOGLE_API_KEY environment variable is set as discussed before.
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Select the model that supports multi-modal input (text and image).
# 'gemini-1.5-flash' is good for general purpose, 'gemini-1.5-pro' is more powerful but might have higher costs.
MODEL_NAME = 'gemini-1.5-flash'
# MODEL_NAME = 'gemini-1.5-pro' # Uncomment this line to try the Pro model

# --- Log File Path ---
# This will create the log file in your JSON output folder
LOG_FILE_PATH = os.path.join('C:/Users/yusef/OneDrive/Desktop/FARA_Report_JSONS', 'fara_validation_report.log')


# --- Helper Function for Logging Errors/Warnings ---
def log_issue(pdf_filename, page_num, issue_type, message, raw_api_response=None, extracted_data_snippet=None):
    """
    Logs issues encountered during PDF processing and data extraction.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] [{issue_type}] Document: '{pdf_filename}', Page: {page_num}\n"
    log_entry += f"  Message: {message}\n"
    if raw_api_response:
        log_entry += f"  Raw API Response: {raw_api_response}\n"
    if extracted_data_snippet:
        log_entry += f"  Extracted Data Snippet: {json.dumps(extracted_data_snippet, indent=2, ensure_ascii=False)}\n"
    log_entry += "-" * 80 + "\n"

    with open(LOG_FILE_PATH, 'a', encoding='utf-8') as f:
        f.write(log_entry)
    print(f"[LOGGED {issue_type}] See '{LOG_FILE_PATH}' for details.")


# --- Function to extract content (text or image) from PDF page ---
def get_pdf_page_content(pdf_path, page_number=0, dpi=300):
    """
    Attempts to extract text from a specific page of a PDF.
    If text extraction yields little to no content (e.g., it's a scanned page),
    it converts the page to a Base64 encoded PNG image string instead.

    Args:
        pdf_path (str): The path to the PDF file.
        page_number (int): The 0-indexed page number to process. Defaults to the first page.
        dpi (int): Dots per inch for rendering the page if converting to image.
                   Higher DPI means better quality but larger image file size.

    Returns:
        dict: A dictionary with 'type' ('text' or 'image') and 'content' (str).
              Returns None if an error occurs opening the PDF or if page is out of bounds.
    """
    try:
        pdf_document = fitz.open(pdf_path)
        if page_number >= len(pdf_document):
            print(f"Error: Page number {page_number} is out of bounds. PDF has {len(pdf_document)} pages.")
            pdf_document.close()
            return None

        page = pdf_document.load_page(page_number)
        text_content = page.get_text("text").strip()

        # Heuristic: if text_content is very short (e.g., less than 100 characters),
        # or if it appears to be mostly page numbers/headers/appendix markers, treat as image.
        if len(text_content) < 100 or \
           "Page" in text_content[:50] or \
           "APPENDIX" in text_content[:50] or \
           "SHORT FORM INDEX" in text_content[:50] or \
           "INTENTIONALLY LEFT BLANK" in text_content.upper(): # Added check for blank pages
            # print(f"Little or no meaningful text found on page {page_number} (or short/header page). Converting to image.")
            matrix = fitz.Matrix(dpi / 72, dpi / 72)
            pix = page.get_pixmap(matrix=matrix)
            img_buffer = io.BytesIO(pix.tobytes("png"))
            img = Image.open(img_buffer)
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            base64_image = base64.b64encode(buffered.getvalue()).decode('utf-8')
            pdf_document.close()
            return {"type": "image", "content": base64_image}
        else:
            pdf_document.close()
            # print(f"Text extracted from page {page_number}: {len(text_content)} characters.")
            return {"type": "text", "content": text_content}

    except Exception as e:
        print(f"Error processing PDF page: {e}")
        return None

# --- Functions to automatically find start and end pages and document type ---
def find_document_range_and_type(pdf_path, start_scan_from_page=0):
    """
    Scans the PDF to find the first and last page containing main FARA listing content,
    and identifies the type of document format.
    Returns a tuple: (document_type_str, first_page_num_0_indexed, last_page_num_0_indexed)
    Returns ("unknown", -1, -1) if unable to determine.
    """
    print(f"Searching for document type and range in '{os.path.basename(pdf_path)}', starting scan from page {start_scan_from_page}...")
    pdf_document = None
    try:
        pdf_document = fitz.open(pdf_path)
        total_pages = len(pdf_document)

        # --- Attempt 1: Detailed Listing Document (Newer Format) ---
        # Look for the exact introductory header
        for i in range(start_scan_from_page, len(pdf_document)):
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip()
            if "LISTING ACCORDING TO THE GEOGRAPHICAL AREA OR NATIONALITY FIELD" in text:
                first_page = i + 1
                print(f"Found 'LISTING ACCORDING TO...' header on page {i}. Assuming 'detailed_listing' type starting on page {first_page}.")

                # Now find last page for this type
                last_page = _find_last_listing_page_for_detailed_type(pdf_path, first_page)
                if last_page == -1: # Fallback if specific last page can't be found
                    last_page = total_pages -1 # Assume until end if not found
                    print(f"Warning: Could not find specific end marker for detailed_listing. Defaulting to last page: {last_page}.")
                return ("detailed_listing", first_page, last_page)

        # --- Attempt 2: "APPENDIX IV - ABSTRACTS" Document (Older Detailed Format) ---
        print("Exact header not found. Trying 'APPENDIX IV - ABSTRACTS' section...")
        for i in range(start_scan_from_page, len(pdf_document)):
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip().upper()
            if "APPENDIX IV" in text and "ABSTRACTS" in text:
                print(f"Found 'APPENDIX IV - ABSTRACTS' on page {i}. Scanning forward for first data entry...")
                # From this page, scan forward to find the actual data entries
                for j in range(i, min(i + 10, len(pdf_document))): # Scan up to 10 pages after appendix IV
                    sub_page = pdf_document.load_page(j)
                    sub_text = sub_page.get_text("text").strip().upper()
                    if ("REGISTRANT" in sub_text and "FOREIGN PRINCIPAL" in sub_text) or \
                       (("NATURE OF SERVICES:" in sub_text or "NATURE OF AGENCY:" in sub_text) and \
                        ("FINANCES:" in sub_text or "DOLLARS" in sub_text or "MONEY" in sub_text or "AMOUNT" in sub_text)):
                        first_page = j
                        print(f"Found data markers on page {first_page} after APPENDIX IV. Assuming 'detailed_listing' type starting on page {first_page}.")
                        last_page = _find_last_listing_page_for_detailed_type(pdf_path, first_page)
                        if last_page == -1: # Fallback if specific last page can't be found
                            last_page = total_pages -1 # Assume until end if not found
                            print(f"Warning: Could not find specific end marker for detailed_listing in APPENDIX IV. Defaulting to last page: {last_page}.")
                        return ("detailed_listing", first_page, last_page)
                print("Found APPENDIX IV but no clear data markers shortly after.")
                # This path indicates Appendix IV is found but it's not the start of detailed listings here.
                # It might be an index instead, so we fall through to the next attempt.

        # --- Attempt 3: "Alphabetical Index" Document (like 910071.pdf) ---
        print("Detailed listing markers not found. Trying 'ALPHABETICAL LIST OF ALL REGISTRANTS' section...")
        for i in range(start_scan_from_page, len(pdf_document)):
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip().upper()
            if "ALPHABETICAL LIST OF ALL REGISTRANTS" in text:
                first_page = i
                print(f"Found 'ALPHABETICAL LIST OF ALL REGISTRANTS' on page {first_page}. Assuming 'alphabetical_index' type.")
                # For these, the listings typically run until the next major appendix or the very end.
                # Re-using the last listing page logic for detailed listings to find the end of this index.
                last_page = _find_last_listing_page_for_detailed_type(pdf_path, first_page)
                if last_page == -1: # Fallback if specific last page can't be found
                    last_page = total_pages -1 # Assume until end if not found
                    print(f"Warning: Could not find specific end marker for alphabetical_index. Defaulting to last page: {last_page}.")
                return ("alphabetical_index", first_page, last_page)

        # --- Attempt 4: Direct detection of a data page using general registrant entry markers (broadest fallback for detailed) ---
        print("Alphabetical index marker not found. Trying direct data page detection for early listings (broad fallback)...")
        for i in range(start_scan_from_page, min(len(pdf_document), 20)): # Scan first 20 pages for direct listings
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip() # FIX: Corrected typo from load_load to load_page

            # Heuristic for older documents that start immediately with a "Registrant" block
            # Look for "Registrant" at the beginning of a line (or near it) and a #number
            # And also some finance/activities indicators
            if ("Registrant" in text[:20] or "REGISTRANT" in text[:20]) and \
               "#" in text[:50] and any(kw in text for kw in ["Finances:", "Activities:", "Nature of Services:", "Political Propaganda:"]):
                first_page = i
                print(f"Found early 'Registrant' entry pattern on page {first_page}. Assuming 'detailed_listing' type.")
                last_page = _find_last_listing_page_for_detailed_type(pdf_path, first_page)
                if last_page == -1: # Fallback if specific last page can't be found
                    last_page = total_pages -1 # Assume until end if not found
                    print(f"Warning: Could not find specific end marker for detailed_listing via registrant pattern. Defaulting to last page: {last_page}.")
                return ("detailed_listing", first_page, last_page)

        print("Could not automatically determine document type or listing range using any known heuristics.")
        return ("unknown", -1, -1)
    except Exception as e:
        print(f"Error determining document type and range: {e}.")
        return ("unknown", -1, -1)
    finally:
        if pdf_document:
            pdf_document.close()

# Helper function for finding the last page of main listing content for detailed documents
def _find_last_listing_page_for_detailed_type(pdf_path, scan_start_from_page):
    """
    Scans the PDF backwards from a given starting page to find the last page of main listing content.
    This is used by find_document_range_and_type.
    Returns the 0-indexed page number or -1 if not found reliably.
    """
    pdf_document = None
    try:
        pdf_document = fitz.open(pdf_path)
        total_pages = len(pdf_document)

        # Start scanning backwards from the end of the expected content or a generous buffer
        scan_from = min(total_pages - 1, scan_start_from_page + 300) # Start from current position + some pages or actual end

        # Prioritize looking for the Appendices from the end
        appendix_markers = [
            "APPENDIX A", "APPENDIX B", "APPENDIX C", "APPENDIX D",
            "APPENDIX E", "APPENDIX F", "ALPHABETICAL LIST OF ALL REGISTRANTS",
            "SHORT FORM INDEX", "THIS PAGE INTENTIONALLY LEFT BLANK",
            "LIST OF DEFENDANTS IN CRIMINAL PROSECUTIONS", # Specific to some older FARA reports
            "APPENDIX VII", "APPENDIX VIII", "APPENDIX IX", "APPENDIX X", # Added more general roman numeral appendices
            "APPENDIX" # Generic "APPENDIX" to catch variations
        ]

        # Scan backwards from the determined last potential content page
        scan_range_end = max(0, total_pages - 200) # Increased scan range for older docs
        for i in range(scan_from, scan_range_end - 1, -1):
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip().upper()

            # Check for explicit appendix markers
            for marker in appendix_markers:
                if marker in text:
                    # Found an appendix, so the last content page is the one before it
                    return i - 1

            # Additional heuristic: If a page is very short (e.g., just page numbers/headers)
            # and seems to be at the transition to appendices
            if len(text) < 100 and i > (total_pages * 0.7): # Check if page is short AND in the last 30% of doc
                 # This is a weak signal, so it's a soft fallback, not a strong return
                 pass # Let the more robust markers work first

        # If no explicit appendix markers found in the scan range.
        # This will search backwards for the last page that has substantial text, assuming it's the last content page.
        print("No explicit appendix markers found. Searching for last page with substantial text content.")
        for i in range(scan_from, 0, -1): # Scan almost all pages backwards
            page = pdf_document.load_page(i)
            text = page.get_text("text").strip()
            if len(text) > 200: # If a page has substantial text (more than 200 chars), it's likely a content page.
                return i

        return total_pages - 1 # Default to last page if absolutely nothing found
    except Exception as e:
        print(f"Error finding last listing page: {e}.")
        return -1 # Indicate failure
    finally:
        if pdf_document:
            pdf_document.close()


# --- Main logic ---
if __name__ == "__main__":
    # --- IMPORTANT: Set your FARA Reports folder path here ---
    FARA_REPORTS_FOLDER = 'C:/Users/yusef/OneDrive/Desktop/FARA_Reports'

    # --- NEW: Define the output folder for JSONs ---
    FARA_JSON_OUTPUT_FOLDER = 'C:/Users/yusef/OneDrive/Desktop/FARA_Report_JSONS'

    # Create the output folder if it doesn't exist
    if not os.path.exists(FARA_JSON_OUTPUT_FOLDER):
        os.makedirs(FARA_JSON_OUTPUT_FOLDER)
        print(f"Created output folder: '{FARA_JSON_OUTPUT_FOLDER}'")


    # --- Define Batch Processing Parameters ---
    BATCH_SIZE = 8  # Number of pages to process in each API batch

    if not os.path.isdir(FARA_REPORTS_FOLDER):
        print(f"Error: FARA Reports folder not found at '{FARA_REPORTS_FOLDER}'. Please update 'FARA_REPORTS_FOLDER'.")
        exit()

    # Get all PDF files in the specified folder
    all_pdf_files_in_folder = [f for f in os.listdir(FARA_REPORTS_FOLDER) if f.lower().endswith('.pdf')]

    if not all_pdf_files_in_folder:
        print(f"No PDF files found in '{FARA_REPORTS_FOLDER}'.")
        exit()

    # Determine which PDFs have already been processed
    # --- TEMPORARILY DISABLED SKIPPING FOR FULL VALIDATION RUN ---
    processed_json_basenames = set()
    # if os.path.exists(FARA_JSON_OUTPUT_FOLDER):
    #     for json_file in os.listdir(FARA_JSON_OUTPUT_FOLDER):
    #         if json_file.lower().endswith('.json'):
    #             processed_json_basenames.add(os.path.splitext(json_file)[0])

    # Filter out PDFs that already have a corresponding JSON output
    pdf_files_to_process = all_pdf_files_in_folder # Process all PDFs for validation run
    print(f"Processing all {len(pdf_files_to_process)} PDF files for validation purposes (skipping of existing JSONs is temporarily disabled).")
    # --- END TEMPORARY DISABLE ---

    # if not pdf_files_to_process:
    #     print("All PDF files in the folder have already been processed. Nothing to do.")
    #     exit() # Removed this exit as we are processing all files for validation

    print(f"Found {len(all_pdf_files_in_folder)} total PDF files in '{FARA_REPORTS_FOLDER}'.")
    print(f"Starting processing for {len(pdf_files_to_process)} remaining PDF files.")

    # Sort files to process in alphabetical order for consistent resume behavior
    pdf_files_to_process.sort()

    processed_files_count = 0 # Initialize counter for processed PDFs in this session

    for pdf_filename in pdf_files_to_process:
        # Wrap processing of each PDF in a try-except to isolate errors
        try:
            pdf_file_path = os.path.join(FARA_REPORTS_FOLDER, pdf_filename)
            output_json_filename = os.path.splitext(pdf_filename)[0] + '.json'
            output_json_full_path = os.path.join(FARA_JSON_OUTPUT_FOLDER, output_json_filename)

            print(f"\n{'='*50}\nProcessing document: '{pdf_filename}' ({processed_files_count + 1} of {len(pdf_files_to_process)} remaining)\n{'='*50}")

            # Determine total pages in the PDF for looping
            try:
                pdf_document_info = fitz.open(pdf_file_path)
                total_pdf_pages = len(pdf_document_info)
                pdf_document_info.close()
                print(f"PDF has a total of {total_pdf_pages} pages (0-indexed).")
            except Exception as e:
                print(f"Error opening PDF to get total page count for '{pdf_filename}': {e}. Skipping this PDF.")
                log_issue(pdf_filename, -1, "ERROR", f"Failed to open PDF: {e}")
                continue # Skip to the next PDF

            # Dynamically determine document type and page range
            doc_type, FIRST_LISTING_PAGE, LAST_LISTING_PAGE = find_document_range_and_type(pdf_file_path, start_scan_from_page=0)

            # --- Handle cases where document type or range couldn't be determined ---
            if doc_type == "unknown":
                print(f"Error: Could not determine the document type or listing range automatically for '{pdf_filename}'. Skipping this PDF.")
                log_issue(pdf_filename, -1, "ERROR", "Could not determine document type or listing range automatically.")
                continue # Skip to the next PDF
            if FIRST_LISTING_PAGE == -1 or LAST_LISTING_PAGE == -1: # This check is secondary as find_document_range_and_type should handle it
                print(f"Error: Invalid page range determined for '{pdf_filename}'. Skipping this PDF.")
                log_issue(pdf_filename, -1, "ERROR", f"Invalid page range determined (First: {FIRST_LISTING_PAGE}, Last: {LAST_LISTING_PAGE}).")
                continue

            # Adjusting for potential edge cases where start/end might be out of range
            if FIRST_LISTING_PAGE < 0: FIRST_LISTING_PAGE = 0
            if LAST_LISTING_PAGE >= total_pdf_pages: LAST_LISTING_PAGE = total_pdf_pages - 1
            if LAST_LISTING_PAGE < FIRST_LISTING_PAGE: # Handle cases where end is before start or becomes invalid
                print(f"Warning: Determined last listing page is before first for '{pdf_filename}'. Adjusting to process a minimal range.")
                log_issue(pdf_filename, -1, "WARNING", f"Adjusted page range: LAST_LISTING_PAGE ({LAST_LISTING_PAGE}) was before FIRST_LISTING_PAGE ({FIRST_LISTING_PAGE}).")
                LAST_LISTING_PAGE = FIRST_LISTING_PAGE

            print(f"\nDynamically determined listing range for '{pdf_filename}': Pages {FIRST_LISTING_PAGE} to {LAST_LISTING_PAGE} (Type: {doc_type})")


            # Load existing data for the current PDF if its JSON file already exists (for resuming)
            # This inner load/save is mainly for mid-PDF crash recovery.
            extracted_data_for_current_pdf = {} # Renamed for clarity that this is for the *current* PDF
            if os.path.exists(output_json_full_path):
                try:
                    with open(output_json_full_path, 'r', encoding='utf-8') as f:
                        extracted_data_for_current_pdf = json.load(f)
                    print(f"Loaded existing data from '{output_json_full_path}' for resuming processing of '{pdf_filename}' (mid-file resume).")
                except json.JSONDecodeError:
                    print(f"Warning: '{output_json_full_path}' exists but is not valid JSON. Starting fresh for '{pdf_filename}'.")
                    log_issue(pdf_filename, -1, "WARNING", f"Existing JSON file '{output_json_filename}' is corrupted. Starting fresh for this PDF.",
                              raw_api_response="N/A", # No raw API response here, it's file read error
                              extracted_data_snippet=f"File content might be invalid JSON. Size: {os.path.getsize(output_json_full_path)} bytes." if os.path.exists(output_json_full_path) else "File not found during error.")
                    extracted_data_for_current_pdf = {}
                except Exception as e:
                    print(f"Error loading existing data from '{output_json_full_path}': {e}. Starting fresh for '{pdf_filename}'.")
                    log_issue(pdf_filename, -1, "ERROR", f"Error loading existing JSON file: {e}. Starting fresh for this PDF.")
                    extracted_data_for_current_pdf = {}

            # The starting page for the current processing session.
            start_processing_from_current_session = FIRST_LISTING_PAGE

            # Loop through pages in batches
            while start_processing_from_current_session <= LAST_LISTING_PAGE:
                batch_start_page = start_processing_from_current_session
                batch_end_page = min(start_processing_from_current_session + BATCH_SIZE - 1, LAST_LISTING_PAGE)

                print(f"\n--- Processing Batch for '{pdf_filename}': Pages {batch_start_page} to {batch_end_page} ---")

                for page_num in range(batch_start_page, batch_end_page + 1):
                    print(f"--- Processing Page {page_num} of '{pdf_filename}' ---")

                    # Check if this page is beyond our determined listing range
                    if page_num > LAST_LISTING_PAGE:
                        print(f"Page {page_num} is beyond the last determined listing page ({LAST_LISTING_PAGE}). Skipping.")
                        continue

                    processed_content = get_pdf_page_content(pdf_file_path, page_number=page_num)

                    if processed_content:
                        contents = []
                        current_prompt = ""

                        # Define prompt based on document type
                        if doc_type == "detailed_listing":
                            current_prompt = (
                                "You are processing a page from a FARA (Foreign Agents Registration Act) detailed listing report. "
                                "Your task is to extract information about organizations lobbying on behalf of foreign principals. "
                                "The structure of each entry is usually: "
                                "ORGANIZATION_NAME (Address) "
                                "Foreign Principal: CLIENT_NAME "
                                "Nature of Services: SERVICE_TYPE "
                                "Activities: DESCRIPTION_OF_ACTIVITIES (this can be long) "
                                "Finances: AMOUNT_SPENT (or 'None Reported') "

                                "Strictly follow these instructions to produce a JSON object for this page. "
                                "The JSON object should have a single top-level key, which is the 'Country or location' found on the page. "
                                "This country name is typically a bold heading at the top of the page (e.g., 'AFGHANISTAN', 'ALBANIA')."
                                "The value of this country key should be an array of objects. "
                                "Each object in this array represents one lobbying organization's entry on this page. "
                                "For each organization, extract the following fields exactly: "
                                "- `organization_name`: The full name of the lobbying organization (e.g., 'Akin, Gump, Strauss, Hauer & Feld, LLP')."
                                "- `registration_number`: The numerical part of the registration number associated with the organization (e.g., '6805' from '#6805'). Extract only the digits. If not found, use an empty string."
                                "- `foreign_principal_client`: The name of the client doing the lobbying (e.g., 'Mohammed Gul Raoufi')."
                                "- `total_finances_reported`: The exact text from the 'Finances:' line (e.g., '$487,030.74 for the six month period ending October 31, 2021' or 'None Reported')."
                                "- `money_amount_numeric`: Extract only the numerical value from 'total_finances_reported'. Remove '$' and commas. If 'None Reported', use 0.0. Convert to a float."
                                "- `activities_description`: The full text under 'Activities:'."
                                "- `contacted_entities`: From the 'Activities:' description, identify and list distinct entities or groups contacted (e.g., 'Members of Congress', 'congressional staff', 'U.S. Government officials', 'media organizations', 'Administration officials', 'think tanks', 'NGOs'). Provide this as an array of strings. If no specific entities are mentioned, provide an empty array `[]`."
                                "- `page_number`: The current page number being processed (e.g., 14, 15, etc.)."
                                "- `document_name`: The name of the PDF document being processed (e.g., 'FARADEC2021-11.pdf')."

                                "Ensure the output is valid, minified JSON. If the page contains no relevant FARA listing entries (e.g., blank, index, or cover page), return an empty JSON object `{}`. "
                                "Do NOT include any explanatory text outside the JSON. Do NOT include any code markdown ticks unless they are part of the JSON."
                            )
                        elif doc_type == "alphabetical_index":
                            current_prompt = (
                                "You are processing a page from a FARA (Foreign Agents Registration Act) alphabetical index report. "
                                "Your task is to extract the registrant names and the countries they represent from this page. "
                                "The structure typically looks like: 'Registrant Name, COUNTRY1, COUNTRY2, ...' or 'Registrant Name, FOREIGN_PRINCIPAL_NAME, COUNTRY'. "
                                "Strictly follow these instructions to produce a JSON object. "
                                "The JSON object should have a single top-level key: `alphabetical_index`. "
                                "The value of `alphabetical_index` should be an array of objects. "
                                "Each object in this array represents one registrant entry on this page. "
                                "For each registrant, extract the following fields exactly: "
                                "- `registrant_name`: The full name of the registrant organization (e.g., 'AC&R/DHB & Bess Advertising, Inc.')."
                                "- `countries_represented`: An array of strings, where each string is a country or entity the registrant represents (e.g., 'Federal Republic of Germany', 'Republic of Korea'). Ensure each country is a separate string in the array. If no countries are explicitly listed for a registrant, provide an empty array `[]`."
                                "- `page_number`: The current page number being processed (e.g., 0, 1, etc.)."
                                "- `document_name`: The name of the PDF document being processed (e.g., '910071.pdf')."

                                "Ensure the output is valid, minified JSON. If the page contains no relevant index entries, return an empty JSON object `{}`. "
                                "Do NOT include any explanatory text outside the JSON. Do NOT include any code markdown ticks unless they are part of the JSON."
                            )
                        else: # Fallback for unknown type - though find_document_range_and_type should prevent this
                            print(f"Warning: Unknown document type encountered for page {page_num} of '{pdf_filename}'. Skipping API call for this page.")
                            log_issue(pdf_filename, page_num, "WARNING", f"Unknown document type for API call.")
                            continue # Skip API call for unknown types


                        if processed_content["type"] == "text":
                            contents.append({"role": "user", "parts": [{"text": current_prompt + "\n\n" + processed_content["content"]}]})
                            # print(f"Sending text content from page {page_num} to Gemini API.") # Commented out to reduce verbosity
                        elif processed_content["type"] == "image":
                            contents.append({"role": "user", "parts": [
                                {"text": current_prompt},
                                {"inlineData": {"mimeType": "image/png", "data": processed_content["content"]}}
                            ]})


                        try:
                            model = genai.GenerativeModel(MODEL_NAME)
                            response = model.generate_content(contents)

                            # Attempt to parse the response as JSON
                            try:
                                parsed_json = json.loads(response.text)

                                # Add page_number and document_name to each entry within the correct structure
                                # and perform validation
                                if doc_type == "detailed_listing":
                                    for country_key, org_list in parsed_json.items():
                                        for org_entry in org_list:
                                            org_entry['page_number'] = page_num
                                            org_entry['document_name'] = pdf_filename
                                            # Basic validation for detailed_listing
                                            if not org_entry.get('organization_name'):
                                                log_issue(pdf_filename, page_num, "WARNING", "Missing 'organization_name' in detailed listing entry.", extracted_data_snippet=org_entry)
                                            if not org_entry.get('registration_number'):
                                                log_issue(pdf_filename, page_num, "WARNING", "Missing 'registration_number' in detailed listing entry.", extracted_data_snippet=org_entry)
                                            if org_entry.get('money_amount_numeric') == 0.0 and "$0.00" not in org_entry.get('total_finances_reported', ''):
                                                # Flag if money is 0.0 but original string looked like a non-zero amount
                                                if any(char.isdigit() for char in org_entry.get('total_finances_reported', '')) and "$" in org_entry.get('total_finances_reported', ''):
                                                    log_issue(pdf_filename, page_num, "WARNING", "Money amount parsed as 0.0 but original string contains digits/dollar sign.", extracted_data_snippet=org_entry)
                                            if not org_entry.get('foreign_principal_client'):
                                                log_issue(pdf_filename, page_num, "WARNING", "Missing 'foreign_principal_client' in detailed listing entry.", extracted_data_snippet=org_entry)

                                elif doc_type == "alphabetical_index":
                                    if "alphabetical_index" in parsed_json:
                                        for entry in parsed_json["alphabetical_index"]:
                                            entry['page_number'] = page_num
                                            entry['document_name'] = pdf_filename
                                            # Basic validation for alphabetical_index
                                            if not entry.get('registrant_name'):
                                                log_issue(pdf_filename, page_num, "WARNING", "Missing 'registrant_name' in alphabetical index entry.", extracted_data_snippet=entry)
                                            if not entry.get('countries_represented'):
                                                log_issue(pdf_filename, page_num, "WARNING", "Missing or empty 'countries_represented' in alphabetical index entry.", extracted_data_snippet=entry)


                                # Merge into main dictionary for the current PDF's data
                                # For alphabetical_index, we'll store it directly under a 'alphabetical_index' list
                                if parsed_json:
                                    if doc_type == "detailed_listing":
                                        for country_name, organizations in parsed_json.items():
                                            if country_name not in extracted_data_for_current_pdf:
                                                extracted_data_for_current_pdf[country_name] = []
                                            extracted_data_for_current_pdf[country_name].extend(organizations)
                                        print(f"Successfully extracted data for countries {list(parsed_json.keys())} from page {page_num}.")
                                    elif doc_type == "alphabetical_index":
                                        if "alphabetical_index" not in extracted_data_for_current_pdf:
                                            extracted_data_for_current_pdf["alphabetical_index"] = []
                                        extracted_data_for_current_pdf["alphabetical_index"].extend(parsed_json.get("alphabetical_index", []))
                                        print(f"Successfully extracted alphabetical index data from page {page_num}.")
                                else:
                                    print(f"No FARA listing data extracted from page {page_num} based on prompt instructions (returned empty JSON).")

                            except json.JSONDecodeError:
                                print(f"Warning: Gemini API response for page {page_num} of '{pdf_filename}' was not valid JSON.")
                                log_issue(pdf_filename, page_num, "ERROR", "Gemini API response was not valid JSON.", raw_api_response=response.text)
                                print("Raw response (may contain errors or non-JSON text):")
                                print(response.text)
                                print("-" * 30)

                        except Exception as e:
                            print(f"Error making Gemini API call for page {page_num} of '{pdf_filename}': {e}")
                            log_issue(pdf_filename, page_num, "ERROR", f"API call failed: {e}",
                                      raw_api_response=f"Content type: {processed_content['type']}, Length: {len(processed_content['content'])}")
                            print("Please ensure your GOOGLE_API_KEY is correctly set and the model name is valid.")
                            print("Very large or complex pages might still cause issues or rate limits.")
                            print("Skipping to next page/batch for this PDF.")
                    else:
                        print(f"Skipping page {page_num} of '{pdf_filename}' due to failure in content extraction.")
                        log_issue(pdf_filename, page_num, "WARNING", "Skipped due to failure in content extraction (e.g., empty page).")

                # --- Save the consolidated data to a JSON file after EACH batch ---
                # This saves current progress for the *current* PDF being processed.
                try:
                    with open(output_json_full_path, 'w', encoding='utf-8') as f:
                        json.dump(extracted_data_for_current_pdf, f, indent=2, ensure_ascii=False) # Changed to current_pdf's data
                    # print(f"\n--- Batch {batch_start_page}-{batch_end_page} data for '{pdf_filename}' saved to '{output_json_full_path}' ---") # Commented out to reduce verbosity
                except Exception as e:
                    print(f"Error saving batch data to JSON file for '{pdf_filename}': {e}")
                    log_issue(pdf_filename, -1, "ERROR", f"Failed to save JSON for batch {batch_start_page}-{batch_end_page}: {e}", extracted_data_snippet=extracted_data_for_current_pdf)

                start_processing_from_current_session += BATCH_SIZE # Move to the next batch starting page
                time.sleep(1) # Small delay to avoid hitting rate limits too quickly

            print(f"\nCompleted processing of '{pdf_filename}'. Final consolidated data is in '{output_json_full_path}'.")
            processed_files_count += 1 # Increment processed file count after successful PDF processing

        except Exception as e:
            print(f"\n!!! CRITICAL ERROR processing PDF '{pdf_filename}': {e}. Skipping to next PDF. !!!")
            log_issue(pdf_filename, -1, "CRITICAL", f"Critical error processing PDF file: {e}. Skipping entire file.",
                      details=f"Outer loop error for file: {pdf_filename}")
            continue # Ensure the loop moves to the next PDF even on critical errors.

    print(f"\nAll {processed_files_count} specified PDF files processed. Process finished.")
